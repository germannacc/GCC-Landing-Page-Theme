<?php 	// This theme uses wp_nav_menu() in one location.
// This theme uses wp_nav_menu() in one location.

register_nav_menus( array(

'primary-menu' => esc_html__( 'Primary Menu', 'gcc-starter-kit' ),
'quicklinks-menu' => esc_html__( 'Quicklinks Menu', 'gcc-starter-kit' ),

));